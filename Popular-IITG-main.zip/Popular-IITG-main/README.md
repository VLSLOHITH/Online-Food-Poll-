# Popular-IITG
Polls 

Developed a Polls App that ranks food eateries around the IITG campus. Users can cast their votes using a QR
Code to their preferred eateries. The results get updated at real-time using Pusher Api and users can see the Polls
demonstrating the results.
– Tech Stack : Express.js, Pusher API, Canvas.js, mongoDB


![poll1](https://user-images.githubusercontent.com/58583959/204960246-36d002ff-b600-4311-82ac-0fd3b05674d5.jpg)
![poll2](https://user-images.githubusercontent.com/58583959/204960265-c7670491-9ee1-403c-9618-8492484c879d.jpg)
